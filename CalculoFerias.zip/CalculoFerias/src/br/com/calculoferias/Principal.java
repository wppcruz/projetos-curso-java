package br.com.calculoferias;

//Importando biblioteca JOptionPane;
import javax.swing.JOptionPane;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Instanciando a classe Proventos
		Proventos prov = new Proventos();
		
		//Declara��o de Vari�veis
		String salarioBruto;
				
		//Declara��o de vetores para os Menu
		Object[] continuar  = {"Deseja fazer outro calculo?", "Sair"};
		Object selecionarOpcao;
		
		do {
			JOptionPane.showMessageDialog(null, "CALCULADORA DE F�RIAS" + ".\nConsiderando o calculo para 30 dias" + ".\nConsiderando INSS � 8%" + ".\nPara iniciar precione Ok." , "\nSeja bem vindo", JOptionPane.PLAIN_MESSAGE);
			salarioBruto = JOptionPane.showInputDialog("Digite o valor do salario Bruto");
			if (salarioBruto.isEmpty()) 
				JOptionPane.showMessageDialog(null, "O campo tem o preenchimento obrigatorio" ,"Aten��o", JOptionPane.WARNING_MESSAGE); 
			else
			salarioBruto = salarioBruto.replace(",", ".");
			
			prov.setSalarioBruto((Double.parseDouble(salarioBruto)));
									
			JOptionPane.showMessageDialog(null, "Valor de f�rias = R$ " + prov.getSalarioBruto() + ".\n1/3 F�rias = R$ " + String.format("%.2f", prov.calculoFerias()) + ".\nDesconto do  INSS = " + String.format("%.2f" , prov.calcularInss()) + ".\nTotal a receber = R$ " + String.format("%.2f", prov.calcularTotal()));
			
			selecionarOpcao = JOptionPane.showInputDialog(null, "Deseja continuar", "Continuar", JOptionPane.INFORMATION_MESSAGE, null, continuar, continuar[0]);
			
			if (selecionarOpcao == "Sair")
				JOptionPane.showMessageDialog(null, "At� Logo!!");
			
			
		}while (selecionarOpcao != "Sair");
		System.exit(0);
	
	}

}
