package br.com.calculoferias;

public class Proventos {

	// Atributos
	private double salarioBruto;
	private double ferias;
	private double adiantamento13;
	private double total;
	private double salarioBmenosinss;
	private double salarioBmenosirpf;

	// M�todos
	//Calculo do 1/3 proporcional
	
	public double calculoFerias() {
		return this.ferias = this.salarioBruto / 3;
	}
	//Calculo do Atiantamento da primeira parcela do 13�
	public double calculoAdiantamento13() {
		return this.adiantamento13 = this.salarioBruto / 2;
	}
	//Calculo dp desconto do Inss sobre as f�rias
	public double calcularInss() {
		return this.salarioBmenosinss = (this.salarioBruto * 0.08);
	}
	//Calculo das Ferias com 1/3 + desconto
	
	public double calcularTotal() {
		return this.salarioBruto + this.calculoFerias() - calcularInss();
	}
	
	/*Calculo do desconto do imposto de renda tabela retirada do link: https://www.contabilidademartinelli.com/ferias-calculo-do-imposto-de-renda/
	public double calcularIrpf() {
		if (this.salarioBruto > 1903.99 && this.salarioBruto < 2826.65) {
			return this.salarioBmenosirpf = (this.salarioBruto * 0.75);
		} else if (this.salarioBruto > 2826.66 && this.salarioBruto < 3751.05) {
			return this.salarioBmenosirpf = (this.salarioBruto * 1.5);
		} else if (this.salarioBruto > 3751.06 && this.salarioBruto < 4664.68) {
			return this.salarioBmenosirpf = (this.salarioBruto * 2.25);
		}else
			return this.salarioBmenosirpf = (this.salarioBruto * 2.75);
			// this.salarioBmenosirpf;*/
	
//M�todos de acesso
	public double getSalarioBruto() {
		return salarioBruto;
	}

	public void setSalarioBruto(double salarioBruto) {
		this.salarioBruto = salarioBruto;
	}

	public double getFerias() {
		return ferias;
	}

	public void setFerias(double ferias) {
		this.ferias = ferias;
	}

	public double getAdiantamento13() {
		return adiantamento13;
	}

	public void setAdiantamento13(double adiantamento13) {
		this.adiantamento13 = adiantamento13;
	}

	public double getSalarioBmenosirpf() {
		return salarioBmenosirpf;
	}

	public void setSalarioBmenosirpf(double salarioBmenosirpf) {
		this.salarioBmenosirpf = salarioBmenosirpf;
	}
}
